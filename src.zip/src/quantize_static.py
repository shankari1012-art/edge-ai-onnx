import os
import numpy as np
from PIL import Image
from onnxruntime.quantization import quantize_static, CalibrationDataReader, QuantType, QuantFormat

class ImageReader(CalibrationDataReader):
    def __init__(self, folder, input_name="input", limit=50):
        imgs = [f for f in os.listdir(folder) if f.lower().endswith((".jpg",".jpeg",".png"))]
        imgs = sorted(imgs)[:limit]
        self.paths = [os.path.join(folder, f) for f in imgs]
        self.input_name = input_name
        self.i = 0

    def get_next(self):
        if self.i >= len(self.paths):
            return None
        p = self.paths[self.i]
        self.i += 1

        img = Image.open(p).convert("RGB").resize((224, 224))
        x = np.array(img).astype(np.float32) / 255.0
        x = np.transpose(x, (2, 0, 1))[None, :]
        return {self.input_name: x}

quantize_static(
    "models/mobilenet_v2_fp32.onnx",
    "models/mobilenet_v2_int8_static.onnx",
    calibration_data_reader=ImageReader("images/calibration", "input", 50),
    quant_format=QuantFormat.QOperator,
    activation_type=QuantType.QUInt8,
    weight_type=QuantType.QInt8,
)

print("Saved: models/mobilenet_v2_int8_static.onnx")
