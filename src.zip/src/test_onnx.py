import numpy as np
import onnxruntime as ort

MODEL_PATH = "models/mobilenet_v2_int8_mobile.onnx"  # or int8_static.onnx

sess = ort.InferenceSession(MODEL_PATH, providers=["CPUExecutionProvider"])

# print input / output names
inp = sess.get_inputs()[0]
out = sess.get_outputs()[0]
print("Input name:", inp.name, "shape:", inp.shape, "type:", inp.type)
print("Output name:", out.name, "shape:", out.shape, "type:", out.type)

# MobileNet expects NCHW float input: (1,3,224,224)
x = np.random.rand(1,3,224,224).astype(np.float32)

y = sess.run(None, {inp.name: x})[0]
print("Output shape:", y.shape)
print("Top-5 indices:", np.argsort(y[0])[-5:][::-1])
